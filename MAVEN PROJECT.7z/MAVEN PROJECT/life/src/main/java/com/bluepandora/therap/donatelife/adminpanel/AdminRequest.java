/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bluepandora.therap.donatelife.adminpanel;

/**
 *
 * @author Biswajit Debnath
 */
public class AdminRequest {
    
    public static final String requestDonatorList="getDonatorList";
    public static final String requestFeedBackList="getFeedBackList";
    public static final String requestAdminList="getAdminList";
    public static final String requestAppUserList="getAppUserList";
    public static final String requestHospitalList="getHospitalList";
    public static final String requestAdminLogin="adminLogin";
    public static final String requestAddHospital="addHospital";
    public static final String requestRemoveHospital="removeHospital";
    public static final String requestRemoveFeedBack="removeFeedBack";
    
}
